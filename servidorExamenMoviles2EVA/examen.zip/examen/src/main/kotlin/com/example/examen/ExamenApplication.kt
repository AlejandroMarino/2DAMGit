package com.example.examen

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ExamenApplication

fun main(args: Array<String>) {
    runApplication<ExamenApplication>(*args)
}
