package com.example.examen.domain

data class Enfermedad(val nombre:String)
