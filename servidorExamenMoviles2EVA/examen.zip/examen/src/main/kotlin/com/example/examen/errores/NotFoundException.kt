package com.example.examen.errores

class NotFoundException(message:String) : RuntimeException(message)
