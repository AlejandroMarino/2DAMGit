package com.example.examen.domain

import java.util.*

data class Partido(
    val id: UUID,
    var nombre: String,
)
