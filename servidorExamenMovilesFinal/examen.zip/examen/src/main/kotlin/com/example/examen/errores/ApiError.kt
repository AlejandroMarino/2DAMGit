package com.example.examen.errores

data class ApiError (val message:String? = "", val debugMessage:String,val code:String)

